var MoneyOps=function (){
}

MoneyOps.add = function(m1,m2){
	if(m1.getCurrency != m2.getCurrency){
		throw "Devises incompatibles !";
	}
	return new money(m1.getValue()+m2.getValue(),m1.getCurrency());
}